This directory should be used to place downloaded and custom libraries (such as
JavaScript libraries) which are used by contributed or custom modules.
